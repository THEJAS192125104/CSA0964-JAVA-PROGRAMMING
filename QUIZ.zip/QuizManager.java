package com.example.quiz;

import java.util.ArrayList;
import java.util.List;

public class QuizManager {

    private List<Quiz> quizzes;

    public QuizManager() {
        this.quizzes = new ArrayList<>();
        initializeQuizzes();
    }

    private void initializeQuizzes() {
        // Add your quizzes here
        Quiz quiz1 = new Quiz("Java Basics");
        quiz1.addQuestion(new Question("What is 2 + 2?", List.of("3", "4", "5"), "4"));
        quiz1.addQuestion(new Question("What is the capital of France?", List.of("Paris", "London", "Berlin"), "Paris"));
        quizzes.add(quiz1);
    }

    public List<Quiz> getQuizzes() {
        return quizzes;
    }
}
