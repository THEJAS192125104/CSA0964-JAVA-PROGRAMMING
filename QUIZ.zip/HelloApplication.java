package com.example.quiz;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private QuizManager quizManager;

    @Override
    public void start(Stage primaryStage) {
        quizManager = new QuizManager(); // Initialize the quiz manager

        primaryStage.setTitle("Quiz App");

        Label titleLabel = new Label("Welcome to the Quiz App");
        Button startButton = new Button("Start Quiz");
        startButton.setOnAction(event -> startQuiz(primaryStage));

        VBox root = new VBox(20);
        root.getChildren().addAll(titleLabel, startButton);
        root.setPrefSize(300, 200);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void startQuiz(Stage primaryStage) {
        QuizScene quizScene = new QuizScene(quizManager, primaryStage);
        quizScene.start();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
