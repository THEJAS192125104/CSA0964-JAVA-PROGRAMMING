package com.example.quiz;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

class QuizScene {

    private QuizManager quizManager;
    private Stage primaryStage;
    private int currentQuizIndex;
    private int currentQuestionIndex;
    private ToggleGroup toggleGroup;
    private VBox root;

    public QuizScene(QuizManager quizManager, Stage primaryStage) {
        this.quizManager = quizManager;
        this.primaryStage = primaryStage;
        this.currentQuizIndex = 0;
        this.currentQuestionIndex = 0;
        this.root = new VBox(20);
        this.root.setPadding(new Insets(20));
    }

    public void start() {
        primaryStage.setTitle("Quiz");

        Quiz currentQuiz = quizManager.getQuizzes().get(currentQuizIndex);

        if (currentQuestionIndex < currentQuiz.getQuestions().size()) {
            displayQuestion(currentQuiz);
        } else {
            displayResult(currentQuiz);
        }

        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void displayQuestion(Quiz quiz) {
        Question question = quiz.getQuestions().get(currentQuestionIndex);

        Label questionLabel = new Label(question.getText());

        toggleGroup = new ToggleGroup();
        VBox optionsBox = new VBox(10);
        for (String option : question.getOptions()) {
            RadioButton radioButton = new RadioButton(option);
            radioButton.setToggleGroup(toggleGroup);
            optionsBox.getChildren().add(radioButton);
        }

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(event -> checkAnswer(quiz));

        root.getChildren().clear();
        root.getChildren().addAll(questionLabel, optionsBox, submitButton);
    }

    private void checkAnswer(Quiz quiz) {
        RadioButton selectedRadioButton = (RadioButton) toggleGroup.getSelectedToggle();
        String selectedAnswer = selectedRadioButton.getText();

        Question question = quiz.getQuestions().get(currentQuestionIndex);
        if (question.isCorrectAnswer(selectedAnswer)) {
            // Correct answer
            currentQuestionIndex++;
        } else {
            // Incorrect answer
            // Handle incorrect answer here
        }

        start();
    }

    private void displayResult(Quiz quiz) {
        int score = currentQuestionIndex;
        Label resultLabel = new Label("Quiz completed!\nYour score: " + score + "/" + quiz.getQuestions().size());
        Button restartButton = new Button("Restart Quiz");
        restartButton.setOnAction(event -> {
            currentQuestionIndex = 0;
            start();
        });

        root.getChildren().clear();
        root.getChildren().addAll(resultLabel, restartButton);
    }
}
